//
//  main.cpp
//  TP1_CS
//
//  Created by Mohamed Abdallaoui Tarek Kamel on 24/1/2022.
//  Copyright © 2022 simorfr. All rights reserved.
//

#include <iostream>

using namespace std;

//Fonction de chiffrement
string chiffrer(string plainText, string key)
{

    string cipherText = "";
   
    int alphabet[26] = {'A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I',
    'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U',
    'V', 'W', 'X', 'Y', 'Z'};

    //Tableau contenant les nombre correspondant aux lettres du texte clair
    int plainTextArray[plainText.size()];
   
    //Tableau contenant les nombres correspondant aux lettres de la clé
    int keyArray[key.size()];
   
    //Supprimer les espaces du texte clair
    for(int i=0; i<plainText.size(); i++)
    {
        if(isspace(plainText[i]))
            plainText.erase(i,1);
    }
   
    //Tableau de correspondance du texte clair
    for(int i=0; i<plainText.size(); i++)
    {
        plainTextArray[i] = plainText[i] - 'A';
    }
   
    //Transformer la clé en majuscule
    for(int i=0; i<key.size(); i++)
    {
        key[i] = toupper(key[i]);
    }
   
    //Tableau de correspondance de la clé
    for(int i=0; i<key.size(); i++)
    {
        keyArray[i] = key[i] - 'A';
    }
   
    //Tableau contenant le texte chiffré en nombres
    int cipherArray[plainText.size()];
   
    //Appliquer le chiffrement
    for(int i=0; i<plainText.size(); i++)
    {
        cipherArray[i] = (plainTextArray[i] + keyArray[i%key.size()])%26;
    }

    //Transformer les nombres en lettres
    for(int i=0; i<plainText.size(); i++)
    {
        cipherText += alphabet[cipherArray[i]];
    }
   
    return cipherText;
}

int main()
{
    //Demander à l'utilistaeur d'entrer le texte chiffré
    cout << "Entrer le texte clair : " << endl;
    string plainText;
    getline(cin, plainText);
   
    //Demander à l'utilistaeur d'entrer la clé
    cout << "Entrer la clé" <<endl;
    string key;
    cin >> key;
   
    string cipher = chiffrer(plainText, key);
   
    cout << "cipher text is: " << cipher << endl;
   

    return 0;
}
